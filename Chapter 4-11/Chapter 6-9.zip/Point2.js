let a = 2;
let b = 1;
document.writeln(`a is: ${a} <br>`)
document.writeln(`b is: ${b} <br>`)
--a;
--b;
let sum1 = --a - --b;
++b;
let sum2 = sum1 + ++b;
b--;
let result = sum2 + b--;
document.writeln(`result is: ${result}`)