let a = 10;
document.writeln(`The value of a is: ${a} <br><br>`)
document.writeln(`.................................................................. <br><br><br>`)
++a;
document.writeln(`The value of ++a is: ${a} <br>`)
document.writeln(`Now the value of a is: ${a} <br><br><br>`)
a++;
document.writeln(`The value of a++ is: ${a} <br>`)
document.writeln(`Now the value of a is: ${a}<br><br><br>`)
--a;
document.writeln(`The value of --a is: ${a} <br>`)
document.writeln(`Now the value of a is: ${a} <br><br><br>`)
a--;
document.writeln(`The value of a-- is: ${a} <br>`)
document.writeln(`Now the value of a is: ${a} <br><br><br>`)