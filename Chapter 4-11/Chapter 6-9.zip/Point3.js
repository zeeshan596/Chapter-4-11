let username;
username = window.prompt("What is your name?")
alert(`Hey! How are you`)
