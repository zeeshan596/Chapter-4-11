let userInput = prompt("Enter a number to display its multiplication table:");
let number;

if (userInput) {
  number = Number(userInput); 
} else {
  number = 5;
}
document.writeln(`<h3>Multiplication Table of ${number}</h3>`);
for (let i = 1; i <= 10; i++) {
  document.writeln(`${number} x ${i} = ${number * i}<br>`);
}
